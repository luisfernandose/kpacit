<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Footer
    |--------------------------------------------------------------------------
    */

    'join' => 'Join',
    'join_us_today' => 'Join us today',
    'subscribe_content' => '#We will send the best deals and offers to your email.',
    'enter_email_here' => 'Enter your email here',

];
