<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Dashboard Translation
    |--------------------------------------------------------------------------
    */

    'dashboard' => 'Dashboard',
    'admin_dashboard_show' => 'Dashboard Show',
];
